export interface Partei {
  id: string;
  name: string;
  kurz?: string;
  farbe?: string;
  programm?: string | null;
}
