// src/main.tsx

import React from "react";
import ReactDOM from "react-dom/client";

import App from "./App";

import CssBaseline from "@mui/material/CssBaseline";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";

import { FavoritenProvider } from "./context/FavoritenContext";
import { NotificationProvider } from "./context/NotificationContext";

import { ThemeContextProvider } from "./context/ThemeContext";
import { BrowserRouter } from "react-router-dom";

function Root() {
  return (
    <ThemeContextProvider>
      <CssBaseline />

      <FavoritenProvider>
        <NotificationProvider>
          <BrowserRouter>
            <App />
          </BrowserRouter>
        </NotificationProvider>
      </FavoritenProvider>
    </ThemeContextProvider>
  );
}

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <React.StrictMode>
    <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="de">
      <Root />
    </LocalizationProvider>
  </React.StrictMode>
);
