import {
  useEffect,
  useRef,
  useMemo,
  forwardRef,
  useImperativeHandle,
} from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";

import "leaflet/dist/leaflet.css";
import "leaflet-routing-machine/dist/leaflet-routing-machine.css";
import "leaflet-routing-machine";

import type { Wahllokal } from "../types/wahllokal";

interface Props {
  center: [number, number]; // User Standort
  wahllokale: Wahllokal[];
  darkMode: boolean;
  onSelectWahllokal?: (wl: Wahllokal) => void;
}

export interface WahllokalMapHandle {
  focusOn: (lat: number, lng: number) => void;
}

export const WahllokalMap = forwardRef<WahllokalMapHandle, Props>(
  function WahllokalMap(
    { center, wahllokale, darkMode, onSelectWahllokal },
    ref
  ) {
    const mapRef = useRef<L.Map | null>(null);
    const routingRef = useRef<L.Routing.Control | null>(null);
    const markersRef = useRef<{ wl: Wahllokal; marker: L.Marker }[]>([]);

    // API für parent
    useImperativeHandle(ref, () => ({
      focusOn(lat: number, lng: number) {
        if (!mapRef.current) return;

        // 1. Auf Marker zoomen
        mapRef.current.setView([lat, lng], 16, { animate: true });

        // 2. Popup öffnen & verschieben
        setTimeout(() => {
          markersRef.current?.forEach((m) => {
            if (m.wl.geo?.lat === lat && m.wl.geo?.lng === lng) {
              m.marker.openPopup();

              // 3. Verschieben, so dass Popup schön zentriert ist
              mapRef.current!.panBy([0, -100], { animate: true });
            }
          });
        }, 250);
      },
    }));

    // Icons
    const userIcon = L.icon({
      iconUrl: "/icons/user-marker.png",
      iconSize: [32, 32],
      iconAnchor: [16, 32],
    });

    const wahllokalIcon = L.icon({
      iconUrl: "/icons/wahllokal-marker.png",
      iconSize: [28, 28],
      iconAnchor: [14, 28],
    });

    const nearestIcon = L.icon({
      iconUrl: "/icons/green-marker.png",
      iconSize: [32, 32],
      iconAnchor: [16, 32],
    });

    // Entfernung berechnen (Haversine)
    const distKm = (lat1: number, lng1: number, lat2: number, lng2: number) => {
      const R = 6371;
      const dLat = ((lat2 - lat1) * Math.PI) / 180;
      const dLng = ((lng2 - lng1) * Math.PI) / 180;
      const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos((lat1 * Math.PI) / 180) *
          Math.cos((lat2 * Math.PI) / 180) *
          Math.sin(dLng / 2) ** 2;
      return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    };

    // 🥇 Nächstgelegenes Wahllokal bestimmen
    const nearest = useMemo(() => {
      if (!center) return null;

      let min = Infinity;
      let nearestWL: Wahllokal | null = null;

      for (const wl of wahllokale) {
        if (!wl.geo) continue;

        const d = distKm(center[0], center[1], wl.geo.lat, wl.geo.lng);
        if (d < min) {
          min = d;
          nearestWL = wl;
        }
      }

      return nearestWL;
    }, [center, wahllokale]);

    // Karte fixen
    useEffect(() => {
      setTimeout(() => {
        mapRef.current?.invalidateSize();
      }, 200);
    }, [center]);

    // Route einzeichnen
    const zeichneRoute = (zielLat: number, zielLng: number) => {
      if (!mapRef.current) return;

      // Vorherige Route entfernen
      if (routingRef.current) {
        routingRef.current.remove();
        routingRef.current = null;
      }

      routingRef.current = L.Routing.control({
        waypoints: [L.latLng(center[0], center[1]), L.latLng(zielLat, zielLng)],
        lineOptions: {
          styles: [{ color: "#1976d2", weight: 5 }],
          extendToWaypoints: false,
          missingRouteTolerance: 0,
        },
        addWaypoints: false,
        show: false,
        routeWhileDragging: false,
        router: L.Routing.osrmv1({
          serviceUrl: "https://router.project-osrm.org/route/v1",
        }),
      }).addTo(mapRef.current);
      function computeRouteBounds(coords: [number, number][]) {
        const latLngs = coords.map((c) => L.latLng(c[1], c[0])); // lng/lat -> lat/lng
        return L.latLngBounds(latLngs);
      }

      // automatisch herauszoomen
      routingRef.current.on("routesfound", function (e) {
        const routes = e.routes;

        if (!routes || routes.length === 0) {
          console.warn("OSRM: Keine Route vorhanden");
          return;
        }

        const route = routes[0];

        // 👉 LRM liefert hier bereits LatLng[] !!
        const coords = route.coordinates as L.LatLng[];

        if (!coords || coords.length === 0) {
          console.warn("Routing error: Keine Koordinaten gefunden:", route);
          return;
        }

        // 👉 Bounds direkt aus LatLng[] berechnen
        const bounds = L.latLngBounds(coords);

        if (!bounds.isValid()) {
          console.warn("Routing error: Bounds aus coords ungültig:", bounds);
          return;
        }

        // 👉 Karte auf gesamte Route zoomen
        mapRef.current!.fitBounds(bounds, {
          padding: [40, 40],
        });
      });
    };

    return (
      <div
        style={{
          width: "100%",
          height: "300px",
          marginBottom: "1rem",
          borderRadius: "8px",
          overflow: "hidden",
        }}
      >
        <MapContainer
          center={center}
          zoom={14}
          scrollWheelZoom={true}
          ref={mapRef}
          style={{ width: "100%", height: "100%" }}
          whenReady={() => {
            setTimeout(() => mapRef.current?.invalidateSize(), 100);
          }}
        >
          <TileLayer
            url={
              darkMode
                ? "https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png"
                : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            }
            attribution="&copy; OpenStreetMap contributors"
          />

          {/* Nutzerstandort */}
          <Marker position={center} icon={userIcon}>
            <Popup>
              <strong>Ihr Standort</strong>
              <br />
              {center[0].toFixed(5)}, {center[1].toFixed(5)}
            </Popup>
          </Marker>

          {/* Wahllokale */}
          {wahllokale.map((wl) => {
            if (!wl.geo) return null;

            const entfernung = distKm(
              center[0],
              center[1],
              wl.geo.lat,
              wl.geo.lng
            );

            // Gehzeit in Minuten (5 km/h)
            const gehzeitMin = Math.round((entfernung / 5) * 60);

            const isNearest = nearest?.id === wl.id;

            return (
              <Marker
                key={wl.id}
                position={[wl.geo.lat, wl.geo.lng]}
                icon={isNearest ? nearestIcon : wahllokalIcon}
                ref={(m) => {
                  if (m) {
                    markersRef.current.push({ wl, marker: m });
                  }
                }}
                eventHandlers={{
                  click: () => {
                    onSelectWahllokal?.(wl);
                  },
                }}
              >
                <Popup>
                  <strong>{wl.name}</strong>
                  <br />
                  {wl.adresse.strasse}
                  <br />
                  {wl.adresse.plz} {wl.adresse.ort}
                  <br />
                  <br />
                  <strong>Entfernung:</strong> {entfernung.toFixed(1)} km
                  <br />
                  <strong>Gehzeit:</strong> {gehzeitMin} min
                  <br />
                  {isNearest && (
                    <div style={{ marginTop: "6px", color: "#FBC02D" }}>
                      ⭐ Nächstgelegenes Wahllokal
                    </div>
                  )}
                  <br />
                  <button
                    onClick={() => {
                      // Popup schließen
                      const entry = markersRef.current.find(
                        (x) => x.wl.id === wl.id
                      );
                      if (entry) entry.marker.closePopup();

                      // Route starten
                      zeichneRoute(wl.geo!.lat, wl.geo!.lng);
                    }}
                    style={{
                      marginTop: "6px",
                      padding: "6px 12px",
                      borderRadius: "4px",
                      background: "#1976d2",
                      border: "none",
                      color: "#fff",
                      cursor: "pointer",
                    }}
                  >
                    Route anzeigen
                  </button>
                </Popup>
              </Marker>
            );
          })}
        </MapContainer>
      </div>
    );
  }
);
