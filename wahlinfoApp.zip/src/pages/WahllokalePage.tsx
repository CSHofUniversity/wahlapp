// src/pages/WahllokalePage.tsx

import { useState, useEffect, useRef } from "react";
import { useTheme } from "@mui/material/styles";

import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import Alert from "@mui/material/Alert";
import TextField from "@mui/material/TextField";

import { sucheWahllokale } from "../services/wahllokale";
import { geocodeAdresse } from "../services/geocode";
import type { Wahllokal } from "../types/wahllokal";
import { Loader } from "../components/Loader";
import {
  WahllokalMap,
  type WahllokalMapHandle,
} from "../components/WahllokalMap";
import { AppCardWithSideInfo } from "../components/AppCardWithSideInfo";

import LocationOnIcon from "@mui/icons-material/LocationOn";
import { PageHeader } from "../components/PageHeader";
import { PageTransition } from "../components/PageTransition";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";

// Entfernung berechnen (Haversine)
function distKm(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371; // Erdradius
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export default function WahllokalePage() {
  const theme = useTheme();
  const darkMode = theme.palette.mode === "dark";

  const [loading, setLoading] = useState(true);
  const [result, setResult] = useState<Wahllokal[]>([]);
  const [center, setCenter] = useState<[number, number] | null>(null);
  const [geoError, setGeoError] = useState<string | null>(null);
  const [adresse, setAdresse] = useState("");

  const mapRef = useRef<WahllokalMapHandle>(null);

  function handleMapFocus(wl: Wahllokal) {
    if (wl.geo && mapRef.current) {
      mapRef.current.focusOn(wl.geo.lat, wl.geo.lng);
    }
  }

  const [sortMode, setSortMode] = useState<"dist" | "name">("dist");

  function sortiereWahllokale(
    mode: "dist" | "name",
    center?: [number, number],
    data?: Wahllokal[]
  ) {
    if (!data) return [];

    if (mode === "name") {
      return [...data].sort((a, b) => a.name.localeCompare(b.name));
    }

    // Abstandsortierung
    if (center) {
      return [...data]
        .map((wl) => ({
          ...wl,
          entfernung: wl.geo
            ? distKm(center[0], center[1], wl.geo.lat, wl.geo.lng)
            : Infinity,
        }))
        .sort((a, b) => (a.entfernung ?? 999999) - (b.entfernung ?? 999999));
    }

    return data;
  }

  // BEIM SEITENSTART: GPS + ALLE WAHLOKALE LADEN
  useEffect(() => {
    async function init() {
      setLoading(true);
      setGeoError(null);

      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          setCenter([lat, lng]);

          try {
            // Alle Wahllokale holen (ohne Filter)
            const alleWl = await sucheWahllokale({});
            // Entfernung hinzufügen + sortieren
            const sortiert = sortiereWahllokale("dist", [lat, lng], alleWl);
            setResult(sortiert);
          } catch (e) {
            console.error(e);
            setGeoError("Fehler beim Laden der Wahllokale.");
          } finally {
            setLoading(false);
          }
        },
        () => {
          setGeoError("GPS konnte nicht aktiviert werden.");
          setLoading(false);
        }
      );
    }

    init();
  }, []);

  async function handleAdresseSearch() {
    if (!adresse.trim()) return;

    setLoading(true);
    setGeoError(null);

    const pos = await geocodeAdresse(adresse);
    if (!pos) {
      setGeoError("Adresse konnte nicht geocodiert werden.");
      setLoading(false);
      return;
    }

    setCenter([pos.lat, pos.lng]);

    try {
      const data = await sucheWahllokale({});
      const sortiert = sortiereWahllokale("dist", [pos.lat, pos.lng], data);
      setResult(sortiert);
    } catch {
      setGeoError("Fehler beim Abrufen der Wahllokale.");
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <Loader />;

  return (
    <PageTransition>
      <PageHeader
        icon={<LocationOnIcon />}
        title="Wahllokale"
        subtitle="Ihre Wahllokale sortiert nach Entfernung"
      />

      <Container sx={{ mt: 2, mb: 10 }}>
        {/* Suchbereich */}
        <Stack spacing={2} sx={{ mb: 2 }}>
          <Stack direction="row" spacing={1}>
            <TextField
              label="Adresse eingeben"
              variant="outlined"
              fullWidth
              value={adresse}
              onChange={(e) => setAdresse(e.target.value)}
            />
            <Button variant="outlined" onClick={handleAdresseSearch}>
              Suchen
            </Button>
          </Stack>
        </Stack>

        {/* Fehleranzeige */}
        {geoError && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {geoError}
          </Alert>
        )}

        {/* Sort Chips */}
        <Stack direction="row" spacing={2} sx={{ mt: 1, mb: 2 }}>
          <ToggleButtonGroup
            value={sortMode}
            exclusive
            onChange={(e, val) => {
              if (!val) return;
              setSortMode(val);

              const newSorted = sortiereWahllokale(
                val,
                center ?? undefined,
                result
              );
              setResult(newSorted);
            }}
            size="small"
          >
            <ToggleButton value="dist">Entfernung</ToggleButton>
            <ToggleButton value="name">Name</ToggleButton>
          </ToggleButtonGroup>
        </Stack>

        {/* Karte */}
        {center && result.length > 0 && (
          <WahllokalMap
            ref={mapRef}
            center={center}
            wahllokale={result}
            darkMode={darkMode}
            onSelectWahllokal={(wl) => console.log("Selected", wl)}
          />
        )}

        {/* Liste */}
        {result.length > 0 && (
          <Typography variant="h6" sx={{ mt: 3, mb: 1 }}>
            Gefundene Wahllokale
          </Typography>
        )}

        {result.map((wl) => {
          const adr = wl.adresse;
          const dist =
            (wl as any).entfernung !== undefined
              ? (wl as any).entfernung.toFixed(1) + " km"
              : "";

          return (
            <AppCardWithSideInfo
              key={wl.id}
              parteiFarbe={"#1976d2"}
              parteiKurz={adr.ort}
            >
              <Typography variant="subtitle1" fontWeight={600}>
                {wl.name}
              </Typography>

              <Typography variant="body2" sx={{ mt: 1 }}>
                {adr.strasse}, {adr.plz} {adr.ort}
              </Typography>

              <Typography variant="body2" sx={{ mt: 1 }}>
                Entfernung: {dist}
              </Typography>

              {wl.barrierefrei && (
                <Alert severity="success" sx={{ mt: 1 }}>
                  Barrierefrei zugänglich
                </Alert>
              )}

              {wl.geo && (
                <Button
                  variant="contained"
                  size="small"
                  sx={{ mt: 2 }}
                  onClick={() => handleMapFocus(wl)}
                >
                  Auf Karte anzeigen
                </Button>
              )}
            </AppCardWithSideInfo>
          );
        })}
      </Container>
    </PageTransition>
  );
}
