// config/appConfig.ts

export const APP_NAME = import.meta.env.VITE_APP_NAME ?? "Kommunale Wahlinfo";

export const APP_TAGLINE = "Wahlinfo & Wahllokalfinder";
