export interface ParteiApi {
  id: string;
  name: string;
  farbe?: string;
  kurz?: string;
  programm?: string | null;
}
